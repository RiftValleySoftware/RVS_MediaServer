import Foundation


/* ###################################################################################################################################### */
/**
 This extension will allow searching and indexing substrings. It comes straight from here: https://stackoverflow.com/a/32306142/879365
 */
extension StringProtocol where Index == String.Index {
    /* ################################################################## */
    /**
     */
    func index(of string: Self, options: String.CompareOptions = []) -> Index? {
        return range(of: string, options: options)?.lowerBound
    }
    
    /* ################################################################## */
    /**
     */
    func endIndex(of string: Self, options: String.CompareOptions = []) -> Index? {
        return range(of: string, options: options)?.upperBound
    }
    
    /* ################################################################## */
    /**
     */
    func indexes(of string: Self, options: String.CompareOptions = []) -> [Index] {
        var result: [Index] = []
        var start = startIndex
        while start < endIndex,
            let range = self[start..<endIndex].range(of: string, options: options) {
                result.append(range.lowerBound)
                start = range.lowerBound < range.upperBound ? range.upperBound :
                    index(range.lowerBound, offsetBy: 1, limitedBy: endIndex) ?? endIndex
        }
        return result
    }
    
    /* ################################################################## */
    /**
     */
    func ranges(of string: Self, options: String.CompareOptions = []) -> [Range<Index>] {
        var result: [Range<Index>] = []
        var start = startIndex
        while start < endIndex,
            let range = self[start..<endIndex].range(of: string, options: options) {
                result.append(range)
                start = range.lowerBound < range.upperBound ? range.upperBound :
                    index(range.lowerBound, offsetBy: 1, limitedBy: endIndex) ?? endIndex
        }
        return result
    }
}

/* ###################################################################################################################################### */
/**
 These are a variety of cool String extensions that add some great extra cheese on the pizza.
 */
extension String {
    /* ################################################################################################################################## */
    /**
     This class is an abstract base class for IP addresses. When we parse a String as an IP address, it will retuen a subclass of this.
     
     When we say "valid," we don't mean the address resolves to anything; just that it is syntactically correct.
     */
    class IPAddress {
        /* ################################################################## */
        /**
         - returns: true, if the IP address is invalid (all 0's).
         */
        var isEmpty: Bool  { return addressArray.isEmpty }
        
        /* ################################################################## */
        /**
         - returns: true, if this is a valid IPV6 address.
         */
        var isV6: Bool  { return false }
        
        /* ################################################################## */
        /**
         - returns: just the address portion of an address/port pair, as a syntactically correct String.
         */
        var address: String  { return "" }
        
        /* ################################################################## */
        /**
         - returns: both the address, and the port, as a syntactically correct String.
         */
        var addressAndPort: String { return "" }
        
        /* ################################################################## */
        /**
         - returns: The TCP port, as an unsigned integer.
         */
        var port: Int = 0
        
        /* ################################################################## */
        /**
         - returns: The actual IP address, as an Array of Int, with each element being one of the displayed elements.
         */
        var addressArray: [Int] = []
    }
    
    /* ################################################################################################################################## */
    /**
     This is a specialization for IPV6
     */
    class IPAddressV4: IPAddress {
        /* ################################################################## */
        /**
         - returns: The IPV4 String representation.
         */
        override var address: String {
            var ret = "0.0.0.0"
            if 4 == self.addressArray.count {
                ret = self.addressArray.reduce("", { (current, new) -> String in
                    var ret = current
                    
                    if !ret.isEmpty {
                        ret += "."
                    }
                    
                    ret += String(new)
                    
                    return ret
                })
            }
            
            return ret
        }
        
        /* ################################################################## */
        /**
         - returns: The IPV4 String representation.
         */
        override var addressAndPort: String {
            return self.address + ":" + String(self.port)
        }
        
        /* ################################################################## */
        /**
         - returns: The IP address element Array, vetted and cleaned for V4
         */
        override var addressArray: [Int] {
            get {
                return super.addressArray
            }
            
            set {
                if 4 == newValue.count, !newValue.reduce(false, { (prev, element) -> Bool in
                    return prev || (0 > element) || (255 < element)
                }) {
                    super.addressArray = newValue
                } else {
                    super.addressArray = []
                    super.port = 0
                }
            }
        }
    }
    
    /* ################################################################################################################################## */
    /**
     This is a specialization for IPV4
     */
    class IPAddressV6: IPAddress {
        /* ################################################################## */
        /**
         - returns: true
         */
        override var isV6: Bool  { return true }
        
        /* ################################################################## */
        /**
         - returns: The IPV6 String representation. If isPadded is true, then each element will be zero-padded.
         */
        override var address: String {
            var ret = "0000:0000:0000:0000:0000:0000:0000:0000"
            if 8 == self.addressArray.count {
                ret = self.addressArray.reduce("", { (current, new) -> String in
                    var ret = current
                    
                    if !ret.isEmpty {
                        ret += ":"
                    }
                    
                    ret += isPadded ? String(format:"%04X", new) : String(format:"%X", new)
                    
                    return ret
                })
            }
            
            return ret
        }
        
        /* ################################################################## */
        /**
         - returns: The IPV6 String representation. If isPadded is true, then each address element will be zero-padded. The port will not be zero-padded.
         */
        override var addressAndPort: String {
            return "[" + self.address + "]:" + String(self.port)
        }
        
        /* ################################################################## */
        /**
         - returns: The IP address element Array, vetted and cleaned for V6
         */
        override var addressArray: [Int] {
            get {
                return super.addressArray
            }
            
            set {
                if 8 == newValue.count, !newValue.reduce(false, { (prev, element) -> Bool in
                    return prev || (0 > element) || (65535 < element)
                }) {
                    super.addressArray = newValue
                } else {
                    super.addressArray = []
                    super.port = 0
                }
            }
        }
        
        /* ################################################################## */
        /**
         - returns: true, if we want the address Strings to be zero-padded (default is false).
         */
        var isPadded: Bool = false
    }
    
    /* ################################################################## */
    /**
     - returns: the localized string (main bundle) for this string.
     */
    var localizedVariant: String {
        return NSLocalizedString(self, comment: "")
    }
    
    /* ################################################################## */
    /**
     This extension lets us uppercase only the first letter of the string (used for weekdays).
     From here: https://stackoverflow.com/a/28288340/879365
     
     - returns: The string, with only the first letter uppercased.
     */
    var firstUppercased: String {
        guard let first = self.first else { return "" }
        return String(first).uppercased() + self.dropFirst()
    }
    
    /* ################################################################## */
    /**
     The following calculated property comes from this: http://stackoverflow.com/a/27736118/879365
     
     This extension function cleans up a URI string.
     
     - returns: a string, cleaned for URI.
     */
    var urlEncodedString: String? {
        let customAllowedSet =  CharacterSet.urlQueryAllowed
        if let ret = self.addingPercentEncoding(withAllowedCharacters: customAllowedSet) {
            return ret
        } else {
            return ""
        }
    }
    
    /* ################################################################## */
    /**
     This extracts an IPV6 address, and, if applicable, TCP port.
     
     The definition of an IPV6 address is:
     
     XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:XXXX
     
     Where "X" is 0...F (Hexadecimal). There are shortcuts (discussed below), but we assume leading zeroes, and all zeores are represented.
     
     If there is an additional TCP port, then that is specified thusly:
     
     [XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:XXXX]:Y
     
     Where Y is a positive integer
     
     SHORTCUTS:
     
     You can specify a range of 0-filled elements by using "::". This is only allowed once in the entire address, like so:
     XXXX:0000:0000:0000:XXXX:0000:0000:XXXX
     
     can be written as:
     
     XXXX::XXXX:0000:0000:XXXX
     
     or:
     
     XXXX:0000:0000:0000:XXXX::XXXX
     
     You can have a maximum of four (4) hexadecimal characters in an element. Case of the hex digits is not relevant. You cannot have chaharcters other than 0-9, A-F in an element.
     
     You must separate elements with colons (:). If you are specifying a port, you must wrap the address in brackets ([]). You must have BOTH brackets if you are wrapping the address.
     
     You can wrap an address in brackets, even if you do not specify a port.
     
     If you specify a port, it must appear after a colon (:), after the closing bracket (]), so you would have "]:12345", to specify TCP Port 12345.
     
     You can have a maximum of eight (8) elements.
     
     Illegal formats and syntax errors result in no address being returned. This function does not guess.
     
     This does things the long way, because it was originally a single string formatter, and it's easier to just leave that stuff in there for now.
     
     - returns: An instance of IPAddressV6, containing the IPV6 address, parsed from the string.
     A port of 0 is undefined. If the address is undefined, it is an empty string ("").
     You cannot have just a port. An undefined address results in an undefined port.
     */
    var iPV6IPAddressAndPort: IPAddressV6 {
        let ret = IPAddressV6()
        
        var parseTarget = self.uppercased()
        if parseTarget.isEmpty {
            parseTarget = "0000:0000:0000:0000:0000:0000:0000:0000"
        }
        
        let charset = CharacterSet(charactersIn: "0123456789ABCDEF:[]").inverted
        
        if !self.isEmpty, nil == parseTarget.rangeOfCharacter(from: charset), 2 > parseTarget.indexes(of: "::").count {
            var addressStartIndex = parseTarget.startIndex
            var addressEndIndex = parseTarget.endIndex
            
            if let openBracket = parseTarget.firstIndex(of: "[") {
                if let closeBracket = parseTarget.firstIndex(of: "]") {
                    addressStartIndex = parseTarget.index(after: openBracket)
                    addressEndIndex = closeBracket
                    
                    let portString = String(parseTarget[addressEndIndex..<parseTarget.endIndex])
                    if 2 < portString.count, let lastColon = portString.firstIndex(of: ":"), let portInt = Int(portString[portString.index(after: lastColon)...]) {
                        ret.port = portInt
                    }
                } else {
                    return ret
                }
            } else if nil != parseTarget.firstIndex(of: "]") {  // Have to have both.
                return ret
            }
            
            let addressString = String(parseTarget[addressStartIndex..<addressEndIndex])
            
            if 0 < addressString.count {
                let addresses = addressString.split(separator: ":", omittingEmptySubsequences: false)
                if !addresses.reduce(false, { (prev, input) -> Bool in
                    return prev || input.count > 4
                }) {
                    // This adds leading zeroes to the elements that actually have addresses.
                    let cleanedAddress: [String] = addresses.map {
                        var ret = ""
                        let charset = CharacterSet(charactersIn: "0123456789ABCDEF").inverted
                        
                        if !$0.isEmpty, 5 > $0.count, nil == $0.rangeOfCharacter(from: charset) {
                            for _ in 0..<(4 - $0.count) {
                                ret += "0"
                            }
                            
                            ret += $0
                        }
                        return ret
                    }
                    
                    if nil != cleanedAddress.firstIndex(of: "") {
                        var cleaned = [String]()
                        
                        for value in cleanedAddress {
                            if !value.isEmpty || !cleaned.contains(value) {
                                cleaned.append(value)
                            }
                        }
                        
                        if let gapIndex = cleaned.firstIndex(of: "") {
                            var before: [String] = []
                            var after: [String] = []
                            
                            before = [String](cleaned[0..<gapIndex])
                            after = [String](cleaned[(gapIndex + 1)...])
                            
                            var beforeIterator = before.makeIterator()
                            var afterIterator = after.makeIterator()
                            
                            let interruption_end = 7 - after.count
                            
                            var newAddressArray = [String]()
                            for index in 0..<8 {
                                if let start = beforeIterator.next() {
                                    newAddressArray.append(start)
                                } else if index > interruption_end, let end = afterIterator.next() {
                                    newAddressArray.append(end)
                                } else {
                                    newAddressArray.append("0000")
                                }
                            }
                            
                            ret.addressArray = newAddressArray.compactMap { Int($0, radix: 16) }
                        }
                    } else if 8 == cleanedAddress.count {
                        ret.addressArray = cleanedAddress.compactMap { Int($0, radix: 16) }
                    }
                }
            }
        }
        
        if ret.addressArray.isEmpty {
            ret.port = 0
        }
        
        return ret
    }
    
    /* ################################################################## */
    /**
     This does the same as above, but for IPV4, which is MUCH simpler.
     
     - returns: An instance of IPAddressV4, loaded with the parsed IP address.
     */
    var iPV4IPAddressAndPort: IPAddressV4 {
        let ret = IPAddressV4()
        
        let charset = CharacterSet(charactersIn: "0123456789.:").inverted
        
        if !self.isEmpty, nil == self.rangeOfCharacter(from: charset) {
            let addrPort = self.components(separatedBy: ":")
            let split = addrPort[0].components(separatedBy: ".")
            
            if 4 == split.count {
                ret.addressArray = split.compactMap { Int($0) }
                
                if 1 < addrPort.count {
                    ret.port = Int(addrPort[1]) ?? 0
                }
            }
        }
        
        return ret
    }
    
    /* ################################################################## */
    /**
     - returns: the String, parsed as an IP address. It will be either an instance of IPAddressV4 or IPAddressV6. It will be nil, if the IP Address is invalid (no instance).
     */
    var ipAddress: IPAddress? {
        let ipV4 = self.iPV4IPAddressAndPort
        
        if ipV4.isEmpty {
            let ipV6 = iPV6IPAddressAndPort
            
            if !ipV6.isEmpty {
                return ipV6
            }
            
            return nil
        }
        
        return ipV4
    }
}

let addresses = [
    "1234:5678:9ABC:DEF0:1234:5678:9ABC:DEF0",
    "0001:0002:0003:0004:0005:0006:0007:0008",
    "1:2:3:4:5:6:7:8",
    "1234:0000:0000:0000:0000:0000:0000:5678",
    "1234::5678",
    "D234::5a78",
    "aBcD::0eF0:fFfF:0000",
    "aBcD:0eF0::fFfF:0000",
    "aBcD:0eF0:fFfF::0000",
    "::aBcD:0eF0:fFfF::0000",
    "aBcD:0000:0000:0eF0:fFfF::",
    "1::2",
    "::1",
    "::",
    "0000:0000:0000:0000:0000:0000:0000:0000",
    "FFFF:FFFF:FFFF:FFFF:FFFF:FFFF:FFFF:FFFF",
    "FFFF:ffff:FFFF:ffff:FFFF:ffff:FFFF:ffff",
    "",
    "supercalifragilisticexpialidocious",
    "TGRE:1234:ARGH:0000:FRIK:0000:oohh:0000",
    "12345:5678:9ABC:DEF0:1234:5678:9ABC:DEF0",
    "1234:56G8:9ABC:DEF0:1234:5678:9ABC:DEF0",
    "1234:5678:9ABC:DEF0:1234:5678:9ABC:DEF0:1234",
    "[1234:5678:9ABC:DEF0:1234:5678:9ABC:DEF0]",
    "[1234:5678:9ABC:DEF0:1234:5678:9ABC:DEF0]:9",
    "[1234:5678:9ABC:DEF0:1234:5678:9ABC:DEF0]:9000",
    "[1234:5678:9ABC:DEF0:1234:5678:9ABC:DEF0]:0090",
    "[1234:5678:9ABC:DEF0:1234:5678:9ABC:DEF0]:0023",
    "]:1",
    "[:1",
    "[]:1",
    "123.123.123.123",
    "0.0.0.0",
    "255.255.255.255",
    "255.255.255",
    "0.1.0.2",
    "0.1.0",
    "255.256.255.255",
    "255.255.255.255:80",
    "255.256.255.255:80",
    "255.255.255.255:0000080",
    "255.255.255.255:-1",
    "255.255.255.255:",
]

var gather: [String] = []
for address in addresses {
    var addressString = ""
    
    if let validAddress = address.ipAddress?.addressAndPort {
        addressString = validAddress
    } else {
        addressString = "INVALID ADDRESS"
    }
    
    gather.append(address + ":")
    gather.append("\t" + addressString)
    if let ipAddress = address.ipAddress as? String.IPAddressV6 {
        ipAddress.isPadded = true
        gather.append("\t" + ipAddress.addressAndPort)
    }
    gather.append("")
}

print("\nRESULT:\n")
for string in gather {
    print(string)
}
