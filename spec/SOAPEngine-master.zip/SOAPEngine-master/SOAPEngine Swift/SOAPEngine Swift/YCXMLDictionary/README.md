# YCXMLDictionary

[![CI Status](http://img.shields.io/travis/taoye/YCXMLDictionary.svg?style=flat)](https://travis-ci.org/taoye/YCXMLDictionary)
[![Version](https://img.shields.io/cocoapods/v/YCXMLDictionary.svg?style=flat)](http://cocoapods.org/pods/YCXMLDictionary)
[![License](https://img.shields.io/cocoapods/l/YCXMLDictionary.svg?style=flat)](http://cocoapods.org/pods/YCXMLDictionary)
[![Platform](https://img.shields.io/cocoapods/p/YCXMLDictionary.svg?style=flat)](http://cocoapods.org/pods/YCXMLDictionary)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

YCXMLDictionary is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod "YCXMLDictionary"
```

## Author

taoye, yetao@cienet.com.cn

## License

YCXMLDictionary is available under the MIT license. See the LICENSE file for more info.
