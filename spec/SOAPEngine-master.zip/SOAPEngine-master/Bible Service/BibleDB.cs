﻿namespace Priore.Bible
{
}
namespace Priore.Bible
{
}
namespace Priore.Bible
{
}
